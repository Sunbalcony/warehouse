from django.apps import AppConfig


class SummerConfig(AppConfig):
    name = 'summer'
