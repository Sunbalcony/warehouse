# from django.contrib import admin
# from .models import Foods, Out
#
#
# class FoodsAdmin(admin.ModelAdmin):
#     list_display = ('gname', 'gnumber', 'gintime', 'guser', 'gother')
#     list_filter = ('gname','guser')
#
# class OutAdmin(admin.ModelAdmin):
#     list_display = ('oname', 'onumber', 'ointime', 'ouser', 'oother')
#     list_filter = ('oname','ouser')
#
# admin.site.register(Foods, FoodsAdmin)
# admin.site.register(Out, OutAdmin)
# # Register your models here.
